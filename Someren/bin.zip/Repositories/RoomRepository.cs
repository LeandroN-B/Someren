﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Someren.Models;

namespace Someren.Repositories
{
    public class RoomRepository : IRoomRepository
    {
        private readonly string _connectionString;

        public RoomRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("LMBdatabase")
                ?? throw new ArgumentNullException(nameof(configuration));
        }

        public List<Room> GetAllRooms()
        {
            List<Room> rooms = new List<Room>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT RoomID, RoomNumber, RoomType, Capacity, Floor, Building FROM Rooms";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                rooms.Add(new Room
                                {
                                    RoomID = Convert.ToInt32(reader["RoomID"]),
                                    RoomNumber = reader["RoomNumber"].ToString() ?? string.Empty,
                                    RoomType = reader["RoomType"].ToString() ?? string.Empty,
                                    Capacity = Convert.ToInt32(reader["Capacity"]),
                                    Floor = Convert.ToInt32(reader["Floor"]),
                                    Building = Enum.TryParse(reader["Building"].ToString(), true, out BuildingType building) ? building : BuildingType.Single
                                });
                            }
                        }
                    }
                    catch (SqlException ex)
                    {
                        throw new Exception($"SQL Error: {ex.Message}", ex);
                    }
                }
            }
            return rooms;
        }

        public Room? GetRoomByID(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT RoomID, RoomNumber, RoomType, Capacity, Floor, Building FROM Rooms WHERE RoomID = @RoomID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RoomID", id);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Room
                                {
                                    RoomID = Convert.ToInt32(reader["RoomID"]),
                                    RoomNumber = reader["RoomNumber"].ToString() ?? string.Empty,
                                    RoomType = reader["RoomType"].ToString()![0],
                                    Capacity = Convert.ToInt32(reader["Capacity"]),
                                    Floor = Convert.ToInt32(reader["Floor"]),
                                    Building = Enum.TryParse(reader["Building"].ToString(), out BuildingType building) ? building : BuildingType.Single,

                                };
                            }
                        }
                    }
                    catch (SqlException ex)
                    {
                        throw new Exception($"SQL Error: {ex.Message}", ex);
                    }
                }
            }
            return null;
        }

        public void AddRoom(Room room)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "INSERT INTO Rooms (RoomNumber, RoomType, Capacity, Floor, Building) VALUES (@RoomNumber, @RoomType, @Capacity, @Floor, @Building)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RoomNumber", room.RoomNumber);
                    command.Parameters.AddWithValue("@RoomType", room.RoomType);
                    command.Parameters.AddWithValue("@Capacity", room.Capacity);
                    command.Parameters.AddWithValue("@Floor", room.Floor);
                    command.Parameters.AddWithValue("@Building", room.Building.ToString());

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        throw new Exception($"SQL Error: {ex.Message}", ex);
                    }
                }
            }
        }

        public void UpdateRoom(Room room)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "UPDATE Rooms SET RoomNumber = @RoomNumber, RoomType = @RoomType, Capacity = @Capacity, Floor = @Floor, Building = @Building WHERE RoomID = @RoomID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RoomID", room.RoomID);
                    command.Parameters.AddWithValue("@RoomNumber", room.RoomNumber);
                    command.Parameters.AddWithValue("@RoomType", room.RoomType);
                    command.Parameters.AddWithValue("@Capacity", room.Capacity);
                    command.Parameters.AddWithValue("@Floor", room.Floor);
                    command.Parameters.AddWithValue("@Building", room.Building.ToString());

                    try
                    {
                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        if (affectedRows == 0)
                        {
                            throw new Exception("No records updated!");
                        }
                    }
                    catch (SqlException ex)
                    {
                        throw new Exception($"SQL Error: {ex.Message}", ex);
                    }
                }
            }
        }

        public void DeleteRoom(Room room)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "DELETE FROM Rooms WHERE RoomID = @RoomID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RoomID", room.RoomID);

                    try
                    {
                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        if (affectedRows == 0)
                        {
                            throw new Exception("No records deleted!");
                        }
                    }
                    catch (SqlException ex)
                    {
                        throw new Exception($"SQL Error: {ex.Message}", ex);
                    }
                }
            }
        }
    }
}
